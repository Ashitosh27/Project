function pass_verify() {
    
    let a = document.querySelector("#input3").value;
    let b = document.querySelector("#input4").value;


   


    if (a != b) {
        alert("Password Does Not Match");
    }

    document.querySelector("#input3").value = "";
    document.querySelector("#input4").value = "";

    let first_name = document.querySelector("#inputfname").value;
    if (first_name.length < 3 && first_name.length > 0) {
        alert("please Enter NAME having more than 3 characters.");
    }

    let last_name = document.querySelector("#inputlname").value;
    if (last_name.length < 3 && last_name.length > 0) {
        alert("please Enter LAST NAME having more than 3 characters.");
    }
}

let email_verify=()=>{
    let email = document.querySelector("#inputemail").value;
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
        return (true)
    }
    else {
        alert("Please Enter Valid Email Address.");
    }

}