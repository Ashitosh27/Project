function Login(){
    let name=document.querySelector("#input1").value;
    if(name.length<5){
        alert("Please Enter User Name Having Character More Than 5.");
    }
    else{
        let new_Name =`<p>${name}</p>`;
    }

    let password=document.querySelector("#input2").value;
    if(isNaN(password)){
        alert("Only Numbers Are Valid In Password.");
    }
    else{
        let new_pass=`<p>${password}</p>`;
        console.log(new_pass);
    }

    document.querySelector("#input1").value="";
    document.querySelector("#input2").value="";

}